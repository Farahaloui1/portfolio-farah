document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("testimonialForm");
    const testimonialsContainer = document.getElementById("studentTestimonials");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        // Récupération des valeurs des champs
        const firstName = document.getElementById("firstName").value;
        const lastName = document.getElementById("lastName").value;
        const opinion = document.getElementById("opinion").value;

        // Création d'un nouveau témoignage
        const testimonial = document.createElement("div");
        testimonial.classList.add("testimonial");
        testimonial.innerHTML = `
            <p class="student-name">${firstName} ${lastName}</p>
            <p class="testimonial-text">${opinion}</p>
        `;

        // Ajout du témoignage à la liste
        testimonialsContainer.appendChild(testimonial);

        // Réinitialisation du formulaire
        form.reset();
    });
    
    
});
function checkQuiz() {
    var score = 0;
    var totalQuestions = 10;

    // Les réponses correctes
    var correctAnswers = [
        { question: "Quelle balise HTML est utilisée pour afficher un titre de niveau 1 ?", answer: "a" }, // <h1>
        { question: "Comment insérer un lien hypertexte en HTML ?", answer: "b" }, // <a href="url">texte</a>
        { question: "Quel est le moyen de changer la couleur d'un texte en CSS ?", answer: "a" }, // color: red;
        { question: "Comment centrer un élément horizontalement avec CSS ?", answer: "a" }, // margin: 0 auto;
        { question: "Comment déclarer une variable en JavaScript ?", answer: "a" }, // var x;
        { question: "Quelle méthode JavaScript est utilisée pour afficher un message dans la console ?", answer: "a" }, // console.log();
        { question: "Comment déclarer une fonction en C ?", answer: "a" }, // void functionName() {}
        { question: "Comment déclarer une variable entière en C ?", answer: "a" }, // int x;
        { question: "Comment déclarer une variable en Python ?", answer: "c" }, // x = 5
        { question: "Comment définir une fonction en Python ?", answer: "a" } // def functionName():
    ];

    var answersList = "";
    
    // Vérification des réponses
    for (var i = 1; i <= totalQuestions; i++) {
        var selected = document.querySelector(`input[name="q${i}"]:checked`);
        var userAnswerText = selected ? selected.value : "Pas de réponse";

        // Ajouter la question et la réponse de l'utilisateur
        answersList += `<strong>${correctAnswers[i - 1].question}</strong><br>`;

        // Vérifier si la réponse est correcte ou incorrecte
        if (userAnswerText === correctAnswers[i - 1].answer) {
            score++;
            answersList += `Réponse correcte : ${correctAnswers[i - 1].answer} (Votre réponse: ${userAnswerText})<br><br>`;
        } else {
            answersList += `Réponse incorrecte. La bonne réponse était : ${correctAnswers[i - 1].answer}. (Votre réponse: ${userAnswerText})<br><br>`;
        }
    }

    // Affichage du score
    document.getElementById("score").innerHTML = `Vous avez obtenu ${score} sur ${totalQuestions}.`;

    // Affichage des réponses et du feedback
    document.getElementById("correctAnswers").innerHTML = answersList;

    // Afficher la section des résultats
    document.getElementById("result").style.display = "block";
}

